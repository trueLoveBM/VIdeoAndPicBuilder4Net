# CameraDirectXCapture
使用 DirectXCapture 控制摄像头，支持视屏和音频的录制和压缩，大师不支持获取单帧图像。内部关系：EXE>依赖>DirectX.Capture.dll>依赖>DShowNET.dll
